# Log of changes

Authors: Lydia Chan, Christine Cheng
Hostname: ee180-23z.stanford.edu

## Single Thread Performance

* original - 5 fps

* add opt flags - 21fps

* chunk and multiply - 30.0 fps

* chunk and shift - 30.1 fps

* restore image and shift - 28.37, 28.43, 27.5 fps

* restore image and multiply - 27.9 fps, 27.1 fps

* multiply has sharper (brighter white lines) image than shift but 1 less fps

* optimize the conv loops - 53 fps

## Single Thread Performance

* optimize for 70 fps