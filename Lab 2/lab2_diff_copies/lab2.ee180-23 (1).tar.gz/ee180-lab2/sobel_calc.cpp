#include "opencv2/imgproc/imgproc.hpp"
#include "sobel_alg.h"
#include <arm_neon.h>
using namespace cv;

/*******************************************
 * Model: grayScale
 * Input: Mat img
 * Output: None directly. Modifies a ref parameter img_gray_out
 * Desc: This module converts the image to grayscale
 ********************************************/
void grayScale(Mat& img, Mat& img_gray_out)
{
  // double color;

  // // Convert to grayscale
  // for (int i=0; i<img.rows; i++) {
  //   for (int j=0; j<img.cols; j++) {
  //     color = .114*img.data[STEP0*i + STEP1*j] +
  //             .587*img.data[STEP0*i + STEP1*j + 1] +
  //             .299*img.data[STEP0*i + STEP1*j + 2];
  //     img_gray_out.data[IMG_WIDTH*i + j] = color;
  //   }
  // }

  // Opt Grayscale Steps
  // 0. Get pointer for img
  // TODO: Check that this is okay ~ divide by 8
  uint16_t b_weight = 29;
  uint16_t g_weight = 150;
  uint16_t r_weight = 77;
  uint8_t* img_ptr = (uint8_t *)img.data;
  uint8_t* img_out_ptr = (uint8_t *)img_gray_out.data;

  // 1. Load R, G, B (vld3..) into uint8x8x3_t
  uint8x8x3_t rgb_chunk;
  uint16x8_t b_expand;
  uint16x8_t g_expand;
  uint16x8_t r_expand;
  uint8x8_t nath_goh;

  // for (int i=0; i < img.rows*img.cols; i+=8) {
  for (int i=0; i<img.rows; i++) {
    for (int j=0; j<img.cols; j+=8) {
      rgb_chunk = vld3_u8(img_ptr + STEP0*i + STEP1*j);

    // 2. Move long (vmovl) R, G, B into uint16x8x3_t
      b_expand = vmovl_u8(rgb_chunk.val[0]);
      g_expand = vmovl_u8(rgb_chunk.val[1]);
      r_expand = vmovl_u8(rgb_chunk.val[2]);

    // 3. Multiply by weights: 0.114, 0.587, 0.299 to get uint16x8_t: 29, 150, 77
      b_expand = vmulq_n_u16(b_expand, b_weight);
      b_expand = vmlaq_n_u16(b_expand, g_expand, g_weight);
      b_expand = vmlaq_n_u16(b_expand, r_expand, r_weight);
      b_expand = vshrq_n_u16(b_expand, 8); // Account for multiplying og weights by 256

      // b_expand = vsraq_n_u16(b_expand, g_expand, 2); // add 4 * g
      // b_expand = vsraq_n_u16(b_expand, r_expand, 1); // add 2 * r
      // b_expand = vshrq_n_u16(b_expand, 3); // Account for multiplying og weights by 8

    // 4. Move narrow (vmovn) R, G, B into uint8x8_t
      nath_goh = vmovn_u16(b_expand);
      
    // 5. Store (vst1_u8) color
       vst1_u8(img_out_ptr + IMG_WIDTH*i + j, nath_goh);
    }
  }

}

/*******************************************
 * Model: sobelCalc
 * Input: Mat img_in
 * Output: None directly. Modifies a ref parameter img_sobel_out
 * Desc: This module performs a sobel calculation on an image. It first
 *  converts the image to grayscale, calculates the gradient in the x
 *  direction, calculates the gradient in the y direction and sum it with Gx
 *  to finish the Sobel calculation
 ********************************************/
void sobelCalc(Mat& img_gray, Mat& img_sobel_out)
{
  // Mat img_outx = img_gray.clone();
  // Mat img_outy = img_gray.clone();

  // Apply Sobel filter to black & white image
  unsigned short sobel;

  // // Calculate the x convolution
  // for (int i=1; i<img_gray.rows; i++) {
  //   for (int j=1; j<img_gray.cols; j++) {
  //     sobel = abs(img_gray.data[IMG_WIDTH*(i-1) + (j-1)] -
		//   img_gray.data[IMG_WIDTH*(i+1) + (j-1)] +
		//   2*img_gray.data[IMG_WIDTH*(i-1) + (j)] -
		//   2*img_gray.data[IMG_WIDTH*(i+1) + (j)] +
		//   img_gray.data[IMG_WIDTH*(i-1) + (j+1)] -
		//   img_gray.data[IMG_WIDTH*(i+1) + (j+1)]);

  //     sobel = (sobel > 255) ? 255 : sobel;
  //     img_outx.data[IMG_WIDTH*(i) + (j)] = sobel;
  //   }
  // }

  // // Calc the y convolution
  // for (int i=1; i<img_gray.rows; i++) {
  //   for (int j=1; j<img_gray.cols; j++) {
  //    sobel = abs(img_gray.data[IMG_WIDTH*(i-1) + (j-1)] -
		//    img_gray.data[IMG_WIDTH*(i-1) + (j+1)] +
		//    2*img_gray.data[IMG_WIDTH*(i) + (j-1)] -
		//    2*img_gray.data[IMG_WIDTH*(i) + (j+1)] +
		//    img_gray.data[IMG_WIDTH*(i+1) + (j-1)] -
		//    img_gray.data[IMG_WIDTH*(i+1) + (j+1)]);

  //    sobel = (sobel > 255) ? 255 : sobel;

  //    img_outy.data[IMG_WIDTH*(i) + j] = sobel;
  //   }
  // }

  // // Combine the two convolutions into the output image
  // for (int i=1; i<img_gray.rows; i++) {
  //   for (int j=1; j<img_gray.cols; j++) {
  //     sobel = img_outx.data[IMG_WIDTH*(i) + j] + img_outy.data[IMG_WIDTH*(i) + j];
  //     sobel = (sobel > 255) ? 255 : sobel;
  //     img_sobel_out.data[IMG_WIDTH*(i) + j] = sobel;
  //   }
  // }

  // Calculate both convolutions
  for (int i=1; i<img_gray.rows-1; i++) {
    for (int j=1; j<img_gray.cols; j++) {
      sobel = abs(2*img_gray.data[IMG_WIDTH*(i-1) + (j-1)] +
      2*img_gray.data[IMG_WIDTH*(i-1) + (j)] +
      2*img_gray.data[IMG_WIDTH*(i) + (j-1)] -
      2*img_gray.data[IMG_WIDTH*(i) + (j+1)] +
      2*img_gray.data[IMG_WIDTH*(i+1) + (j)] -
      2*img_gray.data[IMG_WIDTH*(i+1) + (j+1)]);
      sobel = (sobel > 255) ? 255 : sobel;
      img_sobel_out.data[IMG_WIDTH*(i) + (j)] = sobel;
    }
  }
}
